package ir.maktab.q23.dao;

import ir.maktab.q23.entity.Person;

public interface PersonDaoCustom {
    Integer updatePerson(Person person);
}
