package ir.maktab.q23.config;

import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = "ir.maktab.q23")
@TestConfiguration
public class AppConfig {
}
