package ir.maktab.q23;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Q23ApplicationTests {

	@Test
	void contextLoads() {
	}

}
